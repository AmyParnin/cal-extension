// background.js — Service worker (runs in the background, no DOM access)
// Handles: context menu, auth token, Google Calendar API calls

// ─── Context Menu Setup ───────────────────────────────────────────────────────

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "create-calendar-event",
    title: "Create Calendar event from selection",
    contexts: ["selection"],
  });
});

// ─── Message Handler ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "CREATE_EVENT") {
    createCalendarEvent(message.event)
      .then((result) => sendResponse({ success: true, result }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true; // keep channel open for async response
  }

  if (message.type === "PARSE_TEXT") {
    parseEventFromText(message.text)
      .then((parsed) => sendResponse({ success: true, parsed }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === "CREATE_TASK") {
    createTask(message.task)
      .then((result) => sendResponse({ success: true, result }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (message.type === "OPEN_URL") {
    chrome.tabs.create({ url: message.url });
  }
});

// ─── Context Menu Click ───────────────────────────────────────────────────────

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "create-calendar-event" && info.selectionText) {
    chrome.tabs.sendMessage(tab.id, {
      type: "SHOW_EVENT_PREVIEW",
      text: info.selectionText,
      pageUrl: tab.url,
      pageTitle: tab.title,
    });
  }
});

// ─── Google Calendar API ──────────────────────────────────────────────────────

async function getAuthToken() {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive: true }, (token) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(token);
      }
    });
  });
}

async function createTask(task) {
  const token = await getAuthToken();
  const response = await fetch(
    "https://tasks.googleapis.com/tasks/v1/lists/@default/tasks",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(task),
    }
  );
  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || "Failed to create task");
  }
  return response.json();
}

async function createCalendarEvent(event) {
  const token = await getAuthToken();

  const response = await fetch(
    "https://www.googleapis.com/calendar/v3/calendars/primary/events",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(event),
    }
  );

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || "Failed to create event");
  }

  return response.json();
}

// ─── Title Generation ─────────────────────────────────────────────────────────

// Returns { title: string, error: string|null }
// error is non-null only when an API key is set but the call failed.
async function generateEventTitle(text) {
  const { apiKey } = await chrome.storage.local.get("apiKey");

  if (!apiKey) {
    return { title: heuristicTitle(text), error: null };
  }

  try {
    console.log("[SmartCal] Calling Claude API for title...");
    const { workspaceId } = await chrome.storage.local.get("workspaceId");
    const headers = {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "content-type": "application/json",
      "anthropic-dangerous-direct-browser-access": "true",
    };
    if (workspaceId) headers["anthropic-workspace-id"] = workspaceId;

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers,
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 40,
        messages: [{
          role: "user",
          content: `Extract the calendar event name from this text. Return ONLY the event name — no date, no time, no location, no platform (e.g. "via Google Meet"), no punctuation at the end. Max 60 characters.\n\nText: ${text}`,
        }],
      }),
    });

    if (res.ok) {
      const data = await res.json();
      const title = data.content?.[0]?.text?.trim();
      if (title) {
        console.log("[SmartCal] AI title:", title);
        return { title, error: null };
      }
      return { title: heuristicTitle(text), error: null };
    } else {
      const err = await res.json().catch(() => ({}));
      const errMsg = err?.error?.message || `HTTP ${res.status}`;
      console.error("[SmartCal] Claude API error:", res.status, errMsg);
      return { title: heuristicTitle(text), error: errMsg };
    }
  } catch (e) {
    console.error("[SmartCal] Claude API fetch failed:", e.message);
    return { title: heuristicTitle(text), error: e.message };
  }
}

function heuristicTitle(text) {
  const cleaned = text
    .replace(/\([\s\S]*?\)/g, "")                                           // remove parentheticals like (5:30 PM)
    .replace(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\b\.?\s+\d{1,2}(?:st|nd|rd|th)?(?:[,\s]+\d{4})?/gi, "")
    .replace(/\b\d{1,2}\/\d{1,2}(?:\/\d{2,4})?\b/g, "")                   // MM/DD or MM/DD/YYYY
    .replace(/\b\d{4}-\d{2}-\d{2}\b/g, "")                                 // YYYY-MM-DD
    .replace(/\b\d{1,2}:\d{2}\s*(?:am|pm)?\b/gi, "")                       // times with optional am/pm
    .replace(/\b\d{1,2}\s*(?:am|pm)\b/gi, "")                              // bare am/pm times
    .replace(/\b(today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/gi, "")
    .replace(/\b(sun|mon|tue|wed|thu|fri|sat),?/gi, "")                    // abbreviated weekdays + optional comma
    .replace(/\bvia\s+\S+(?:\s+\S+)?/gi, "")                               // "via Zoom", "via Google Meet" etc.
    .replace(/[\n\r]+/g, " ")
    .replace(/\b(at|by|from)\s*$/i, "")                                    // dangling prepositions left after stripping time/day
    .replace(/^[\s:,–\-–—]+/, "").replace(/[\s:,.\-–—]+$/, "")            // leading/trailing separators incl em-dash
    .replace(/\s+/g, " ")
    .trim();
  const result = cleaned.length > 0 ? cleaned : text.trim();
  return result.length > 80 ? result.slice(0, 77) + "…" : result;
}

// ─── Event Parsing ────────────────────────────────────────────────────────────

async function parseEventFromText(text) {
  const { date, hasTime } = extractDateInfo(text);
  const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const { title: summary, error: aiError } = await generateEventTitle(text);

  if (!hasTime) {
    // No time found → treat as all-day event.
    // Google Calendar end date is exclusive, so add 1 day.
    const startStr = toDateString(date);
    const nextDay  = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
    return {
      summary,
      start: { date: startStr },
      end:   { date: toDateString(nextDay) },
      description: `Created from: ${text}`,
      allDay: true,
      aiError: aiError || null,
    };
  }

  const endDate = new Date(date.getTime() + 60 * 60 * 1000);
  return {
    summary,
    start: { dateTime: date.toISOString(), timeZone: tz },
    end:   { dateTime: endDate.toISOString(), timeZone: tz },
    description: `Created from: ${text}`,
    allDay: false,
    aiError: aiError || null,
  };
}

// Returns { date: Date, hasTime: boolean }
function extractDateInfo(text) {
  const now   = new Date();
  const lower = text.toLowerCase();

  // ── Time extraction ──────────────────────────────────────────────────────
  let hour   = null;
  let minute = 0;

  const ampmMatch = lower.match(/\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b/);
  const h24Match  = lower.match(/\b([01]?\d|2[0-3]):([0-5]\d)\b/);

  if (ampmMatch) {
    hour   = parseInt(ampmMatch[1]);
    minute = ampmMatch[2] ? parseInt(ampmMatch[2]) : 0;
    if (ampmMatch[3] === "pm" && hour < 12) hour += 12;
    if (ampmMatch[3] === "am" && hour === 12) hour = 0;
  } else if (h24Match) {
    hour   = parseInt(h24Match[1]);
    minute = parseInt(h24Match[2]);
  } else if (/\bnoon\b/.test(lower)) {
    hour = 12; minute = 0;
  } else if (/\bmidnight\b/.test(lower)) {
    hour = 0; minute = 0;
  }

  const hasTime = hour !== null;

  // ── Date extraction ──────────────────────────────────────────────────────
  let date = null;

  if (lower.includes("today")) {
    date = new Date(now);
  } else if (lower.includes("tomorrow")) {
    date = new Date(now);
    date.setDate(now.getDate() + 1);
  }

  // Month-name date — checked BEFORE weekday so "Thursday, October 1" picks
  // up October 1 rather than "next Thursday".
  // Handles: "June 15", "Jun 15", "Sept. 15", "Oct 1, 2026", "October 1 2026"
  if (!date) {
    const MONTHS = ["january","february","march","april","may","june",
                    "july","august","september","october","november","december"];
    const mMatch = lower.match(
      /\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:[,\s]+(\d{4}))?\b/
    );
    if (mMatch) {
      const abbr = mMatch[1];
      const m    = MONTHS.findIndex(name => name.startsWith(abbr));
      const d    = parseInt(mMatch[2]);
      const y    = mMatch[3] ? parseInt(mMatch[3]) : now.getFullYear();
      date = new Date(y, m, d);
      if (!mMatch[3] && date < now) date.setFullYear(now.getFullYear() + 1);
    }
  }

  // Numeric date: MM/DD or MM/DD/YYYY
  if (!date) {
    const slashMatch = text.match(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/);
    if (slashMatch) {
      const m = parseInt(slashMatch[1]) - 1;
      const d = parseInt(slashMatch[2]);
      const y = slashMatch[3]
        ? (slashMatch[3].length === 2 ? 2000 + parseInt(slashMatch[3]) : parseInt(slashMatch[3]))
        : now.getFullYear();
      date = new Date(y, m, d);
      if (!slashMatch[3] && date < now) date.setFullYear(now.getFullYear() + 1);
    }
  }

  // ISO date: YYYY-MM-DD (checked before dash format to avoid ambiguity)
  if (!date) {
    const isoMatch = text.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoMatch) {
      date = new Date(parseInt(isoMatch[1]), parseInt(isoMatch[2]) - 1, parseInt(isoMatch[3]));
    }
  }

  // Dash date: MM-DD-YY or MM-DD-YYYY (e.g. "06-18-26" or "06-18-2026")
  if (!date) {
    const dashMatch = text.match(/\b(\d{1,2})-(\d{1,2})-(\d{2,4})\b/);
    if (dashMatch) {
      const m = parseInt(dashMatch[1]) - 1;
      const d = parseInt(dashMatch[2]);
      const y = dashMatch[3].length <= 2 ? 2000 + parseInt(dashMatch[3]) : parseInt(dashMatch[3]);
      if (m >= 0 && m <= 11 && d >= 1 && d <= 31) {
        date = new Date(y, m, d);
      }
    }
  }

  // Named weekday — full or abbreviated: "Monday", "Mon", "next Tue", "Thursday"
  if (!date) {
    const DAYS = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
    const dayMatch = lower.match(
      /\b(next\s+)?(sun(?:day)?|mon(?:day)?|tue(?:s(?:day)?)?|wed(?:nesday)?|thu(?:r(?:s(?:day)?)?)?|fri(?:day)?|sat(?:urday)?)\b/
    );
    if (dayMatch) {
      const abbr    = dayMatch[2];
      const target  = DAYS.findIndex(d => d.startsWith(abbr));
      let daysAhead = target - now.getDay();
      if (daysAhead <= 0 || dayMatch[1]) daysAhead += 7;
      date = new Date(now);
      date.setDate(now.getDate() + daysAhead);
    }
  }

  // ── Fallback ─────────────────────────────────────────────────────────────
  if (!date) {
    date = new Date(now);
    date.setDate(now.getDate() + 1);
  }

  date.setHours(hasTime ? hour : 0, hasTime ? minute : 0, 0, 0);
  return { date, hasTime };
}

function toDateString(date) {
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

// Allow unit testing in Node without the Chrome runtime
if (typeof module !== "undefined") {
  module.exports = { extractDateInfo, parseEventFromText, heuristicTitle };
}
